import React from "react";

/* Home component is the default page location */
export default function Home() {
  return (
    <section>
      <h1>What Person is This?</h1>
      <p>Select a category to play the game:</p>
    </section>
  );
}