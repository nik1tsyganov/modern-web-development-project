import React from "react";
import RateView from "./RateView";

/* MAIN MODULE WITH STATEFUL PARENT AND STATELESS CHILD */
const RateModule = () => {
  return (
    <div>
      <RateView />
    </div>
  );
};

export default RateModule;