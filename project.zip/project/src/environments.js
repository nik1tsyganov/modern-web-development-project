module.exports = {
    APPLICATION_ID: "C9VUxFuFcDLc9nq44KydgZ48d7J6XbvN1gwymJfN",
    JAVASCRIPT_KEY: "FZJmNrPLQqwOqbp3Ms20tDsjYDDgtEUfFSiYy5lK",
    SERVER_URL: "https://parseapi.back4app.com/"
  };