# Change Log

All notable changes to this project will be documented in this file.

# [0.2.0] - 2022-06-29

### Added

Parse for data read/write, more components (i.e. Historical, Footer), added routing for page navigation

### Changed

### Fixed

